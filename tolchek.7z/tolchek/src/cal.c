#include "cal.h"
#include "delete_space.h"
#include <ctype.h>

struct lex expre[100];

void fill_exp(void) {

}


