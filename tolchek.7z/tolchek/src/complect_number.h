#ifndef COMPLECT_NUMBER_H
#define COMPLECT_NUMBER_H


int complect_int(int begin);

#endif // COMPLECT_NUMBER_H
