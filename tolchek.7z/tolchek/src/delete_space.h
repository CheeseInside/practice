#ifndef DELETE_SPACE_H
#define DELETE_SPACE_H

#include "cal.h"

extern char expr[LEN];
void delete_space(void);

#endif // DELETE_SPACE_H
