#include "complect_number.h"
#include <ctype.h>
#include "delete_space.h"
#include <stdlib.h>

int complect_int(int begin) {
    char result[20];

    int cnt = 0;

    while (isdigit(expr[cnt + begin])) {
        result[cnt++] = expr[cnt + begin];
    }

    result[cnt] = '\0';

    return atoi(result);
}
