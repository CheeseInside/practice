#include "parselexem.h"

int parse_lexem(int filler_cnt, int begin) {
    switch (expr[begin]) {
    case '+':
        expre[filler_cnt].type = 'A';
        expre[filler_cnt].value = 0;
        break;
    case '-':
        expre[filler_cnt].type = 'E';
        expre[filler_cnt].value = 0;
        break;
    case '*':
        expre[filler_cnt].type = 'M';
        expre[filler_cnt].value = 0;
        break;
    case '/':
        expre[filler_cnt].type = 'D';
        expre[filler_cnt].value = 0;
        break;
    case '(':
        expre[filler_cnt].type = 'L';
        expre[filler_cnt].value = 0;
        break;
    case ')':
        expre[filler_cnt].type = 'R';
        expre[filler_cnt].value = 0;
        break;
    default:
        expre[filler_cnt].type = 'N';
        expre[filler_cnt].value = complect_int(begin);

        while (isdigit(expr[begin+1])) {
            begin++;
        }
    }
    printf("%c\n", expre[filler_cnt].type);
    begin++;
    return begin;
}
