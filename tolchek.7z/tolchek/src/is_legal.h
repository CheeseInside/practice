#ifndef IS_LEGAL_H
#define IS_LEGAL_H
#include "stdbool.h"

bool is_valid(void);

#endif // IS_LEGAL_H
