#ifndef PARSEEXPRESSION_H
#define PARSEEXPRESSION_H
#include "parselexem.h"


void full_parce(void);

#endif // PARSEEXPRESSION_H
