#include "parseexpression.h"


void full_parce()
{
    int begin = 0;
    int filler = 0;
    while(begin < strlen(expr))
    {
        begin = parse_lexem(filler++, begin);
    }
}
