#ifndef CAL_H
#define CAL_H

#define LEN 100

struct lex {
    char type;
    int value;
};

extern struct lex expre[LEN];
void fill_exp(void);

#endif // CAL_H
