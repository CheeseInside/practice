#include <stdio.h>
#include <stdlib.h>
#include "delete_space.h"
#include "cal.h"
#include "parselexem.h"



int main()
{

    //printf("%d", parse_lexem(1, 3));
    full_parce();
    printf("\n%s", expr);



    for (int i = 0; i < 12; i++) {
        printf("\n%c", expre[i].type);
        printf("   %d", expre[i].value);
    }



    return 0;
}
