#ifndef PARSELEXEM_H
#define PARSELEXEM_H

#include "delete_space.h"
int parse_lexem(int filler_cnt, int begin);

#endif // PARSELEXEM_H
