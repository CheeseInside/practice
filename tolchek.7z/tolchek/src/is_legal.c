#include "is_legal.h"
#include "stdio.h"
#include "cal.h"

delete_space();

int left_cnt = 0;
int right_cnt = 0;

bool is_valid(void)
{
    for (size_t i = 0; i < 15; i++)
    {
        if(expre[i].type == expre[i+1].type && expre[i].type != 'L' && expre[i].type != 'R ')
        {
            return false;
        }

        if (expre[i].type == 'L')
        {
            left_cnt++;
        }
        if (expre[i].type == 'R')
        {
            right_cnt++;
        }
    }

    if(right_cnt != left_cnt)
    {
        return false;
    }

    return true;


}
