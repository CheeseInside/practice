#include "delete_space.h"
#include <stdlib.h>
#include <string.h>


char expr[LEN] = "484 + (5*34 -  34*67-34/6)";

void delete_space(void) {
    int counter = 0;
    for (size_t i = 0; i < strlen(expr); i++) {
        if (expr[i] == ' ') {
            continue;
        }
        else {
            expr[counter++] = expr[i];
        }
    }
    expr[counter] = '\0';
}
