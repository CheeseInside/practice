#ifdef TEST

#include "unity.h"

#include "parselexem.h"

void setUp(void)
{
}

void tearDown(void)
{
}

void test_parselexem_NeedToImplement(void)
{

}

#endif // TEST
