#ifdef TEST

#include "unity.h"

#include "is_legal.h"

void setUp(void)
{
}

void tearDown(void)
{
}

void test_is_legal_NeedToImplement(void)
{
    TEST_IGNORE_MESSAGE("Need to Implement is_legal");
}

#endif // TEST
