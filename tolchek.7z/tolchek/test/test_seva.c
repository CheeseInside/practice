#ifdef TEST

#include "unity.h"

#include "seva.h"

void setUp(void)
{
}

void tearDown(void)
{
}

void test_seva_NeedToImplement(void)
{
    TEST_IGNORE_MESSAGE("Need to Implement seva");
}

#endif // TEST
