#ifdef TEST

#include "unity.h"

#include "cal.h"

void setUp(void)
{
}

void tearDown(void)
{
}

void test_cal_NeedToImplement(void)
{
    TEST_IGNORE_MESSAGE("Need to Implement cal");
}

#endif // TEST
