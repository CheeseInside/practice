#ifdef TEST

#include "unity.h"

#include "complect_number.h"
#include "delete_space.h"

void setUp(void)
{
}

void tearDown(void)
{
}

void test_complect_number_NeedToImplement(void)
{
    int result = complect_int(0);
    TEST_ASSERT_EQUAL_INT(484, result);
}
#endif // TEST
