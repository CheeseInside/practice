#ifdef TEST

#include "unity.h"

#include "delete_space.h"

void setUp(void)
{
}

void tearDown(void)
{
}

void test_delete_space_NeedToImplement(void)
{
    TEST_IGNORE_MESSAGE("Need to Implement delete_space");
}

#endif // TEST
